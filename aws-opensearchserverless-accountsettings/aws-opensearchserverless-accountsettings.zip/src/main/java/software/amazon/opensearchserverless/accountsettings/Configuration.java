package software.amazon.opensearchserverless.accountsettings;

class Configuration extends BaseConfiguration {

    public Configuration() {
        super("aws-opensearchserverless-accountsettings.json");
    }
}
